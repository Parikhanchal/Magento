<?php

namespace Kitchen\CsvUpload\Controller\Index;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Checkout\Model\Cart;
use Magento\Catalog\Model\ProductRepository;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Framework\Message\ManagerInterface;


class AddToCart extends Action
{
    protected $cart;
    protected $productRepository;
    protected $resultJsonFactory;
    protected $formKeyValidator;
    protected $scopeConfig;
    protected $messageManager;


    public function __construct(
        Context $context,
        Cart $cart,
        ProductRepository $productRepository,
        JsonFactory $resultJsonFactory,
        Validator $formKeyValidator,
        ScopeConfigInterface $scopeConfig,
        ManagerInterface $messageManager

    ) {
        parent::__construct($context);
        $this->cart = $cart;
        $this->productRepository = $productRepository;
        $this->resultJsonFactory = $resultJsonFactory;
        $this->formKeyValidator = $formKeyValidator;
        $this->scopeConfig = $scopeConfig;
        $this->messageManager = $messageManager;

    }

    public function execute()
    {
        // Validate form key if needed
        // if (!$this->formKeyValidator->validate($this->getRequest())) {
        //     return $this->resultRedirectFactory->create()->setPath('*/*/');
        // }

        $resultJson = $this->resultJsonFactory->create();
        $sku = $this->getRequest()->getParam('sku');
        $qty = $this->getRequest()->getParam('qty', 1);
        $assemblyCode = $this->getRequest()->getParam('assembly_code');
        $hing = $this->getRequest()->getParam('hing');

        try {
            $product = $this->productRepository->get($sku);
            $productOptions = $product->getOptions();

            $customOptions = [];

            foreach ($productOptions as $option) {
                if ($option->getTitle() === 'Select Assembly :' && $assemblyCode) {
                    $values = $option->getValues();
                    foreach ($values as $value) {
                        if ($value->getTitle() === $assemblyCode) {
                            $customOptions[$option->getId()] = $value->getId();
                            break;
                        }
                    }
                }
                if ($option->getTitle() === 'Select Hinge :' && $hing) {
                    $values = $option->getValues();
                    foreach ($values as $value) {
                        if ($value->getTitle() === $hing) {
                            $customOptions[$option->getId()] = $value->getId();
                            break;
                        }
                    }
                }
            }

            $params = [
                'product' => $product->getId(),
                'qty' => $qty,
                'options' => $customOptions
            ];

            $this->cart->addProduct($product, $params);
            $this->cart->save();
            $this->messageManager->addSuccessMessage("$sku successfully added to cart.");


            return $resultJson->setData(['success' => true, 'message' => __('Product added to cart.')]);
        } catch (LocalizedException $e) {
            return $resultJson->setData(['success' => false, 'message' => $e->getMessage()]);
        } catch (\Exception $e) {
            return $resultJson->setData(['success' => false, 'message' => __('Cannot add the item to shopping cart.')]);
        }
    }
}
