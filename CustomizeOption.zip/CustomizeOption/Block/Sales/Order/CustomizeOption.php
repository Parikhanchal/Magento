<?php

namespace Kitchen365\CustomizeOption\Block\Sales\Order;

use Magento\Sales\Model\Order;
use Magento\Framework\View\Element\Template\Context;
use Magento\Tax\Model\Config;
use Magento\Framework\App\Config\ScopeConfigInterface;

class CustomizeOption extends \Magento\Framework\View\Element\Template
{

    /**
     * Tax configuration model
     *
     * @var Config
     */
    protected $_config;

    /**
     * @var Order
     */
    protected $_order;

    /**
     * @var \Magento\Framework\DataObject
     */
    protected $_source;

    /**
     * @var ScopeConfigInterface
     */
    protected $_scopeConfig;

    /**
     * @param Context $context
     * @param Config $taxConfig
     * @param ScopeConfigInterface $scopeConfig
     * @param array $data
     */
    public function __construct(
        Context $context,
        Config $taxConfig,
        ScopeConfigInterface $scopeConfig,
        array $data = []
    ) {
        $this->_config = $taxConfig;
        $this->_scopeConfig = $scopeConfig;
        parent::__construct($context, $data);
    }

    /**
     * Check if we need to display full tax total info
     *
     * @return bool
     */
    public function displayFullSummary()
    {
        return true;
    }

    /**
     * Get data (totals) source model
     *
     * @return \Magento\Framework\DataObject
     */
    public function getSource()
    {
        return $this->_source;
    }

    /**
     * Get store
     *
     * @return \Magento\Store\Api\Data\StoreInterface
     */
    public function getStore()
    {
        return $this->_order->getStore();
    }

    /**
     * Get order
     *
     * @return Order
     */
    public function getOrder()
    {
        return $this->_order;
    }

    /**
     * Get label properties
     *
     * @return array
     */
    public function getLabelProperties()
    {
        return $this->getParentBlock()->getLabelProperties();
    }

    /**
     * Get value properties
     *
     * @return array
     */
    public function getValueProperties()
    {
        return $this->getParentBlock()->getValueProperties();
    }

    /**
     * Initialize all order totals related to tax
     *
     * @return $this
     */
    public function initTotals()
    {
        $parent = $this->getParentBlock();
        $this->_order = $parent->getOrder();
        $this->_source = $parent->getSource();
        $LaberPrice = $this->_order->getLaberPrice();


        if ($LaberPrice !== null && $LaberPrice != 0) {
            

            $optionprice = new \Magento\Framework\DataObject(
                [
                    'code' => 'laber_price',
                    'value' => $LaberPrice,
                    'label' => 'Laber Price',
                        
                ]
            );

            $parent->addTotal($optionprice, 'subtotal');
        }

        return $this;
    }
}
