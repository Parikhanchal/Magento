<?php

namespace Kitchen365\CustomizeOption\Block\Adminhtml\Sales\Order\Invoice;

use Magento\Framework\View\Element\Template\Context;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Sales\Model\Order\Invoice;
use Magento\Framework\DataObject;

class CustomizeOption extends \Magento\Framework\View\Element\Template
{
    protected $_invoice;
    protected $_source;
    protected $_scopeConfig;

    /**
     * @param Context $context
     * @param ScopeConfigInterface $scopeConfig
     * @param array $data
     */
    public function __construct(
        Context $context,
        ScopeConfigInterface $scopeConfig,
        array $data = []
    ) {
        $this->_scopeConfig = $scopeConfig;
        parent::__construct($context, $data);
    }

    /**
     * Get data (totals) source model
     *
     * @return \Magento\Framework\DataObject
     */
    public function getSource()
    {
        return $this->_source;
    }

    /**
     * Get store
     *
     * @return \Magento\Store\Api\Data\StoreInterface
     */
    public function getStore()
    {
        return $this->_invoice->getStore();
    }

    /**
     * @return Invoice
     */
    public function getInvoice()
    {
        return $this->_invoice;
    }

    public function initTotals()
    {
        $parent = $this->getParentBlock();
        $this->_invoice = $parent->getInvoice();
        $this->_source = $parent->getSource();

        $laberPrice = $this->_invoice->getLaberPrice();

        if ($laberPrice !== null && $laberPrice != 0) {
            $laberPriceTotal = new DataObject(
                [
                    'code' => 'laber_price',
                    'value' => $laberPrice,
                    'label' => __('Laber Price'),
                ]
            );

            $parent->addTotal($laberPriceTotal, 'subtotal');
        }

        return $this;
    }
}
