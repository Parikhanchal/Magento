<?php

namespace Kitchen365\CustomizeOption\Block\Adminhtml\Sales\Order\Creditmemo;

use Magento\Framework\View\Element\Template\Context;
use Magento\Framework\DataObject;
use Magento\Sales\Model\Order\Creditmemo;
use Magento\Framework\App\Config\ScopeConfigInterface;

class CustomizeOption extends \Magento\Framework\View\Element\Template
{
    protected $_creditmemo;
    protected $_source;
    protected $_scopeConfig;

    /**
     * @param Context $context
     * @param ScopeConfigInterface $scopeConfig
     * @param Creditmemo|null $creditmemo
     * @param array $data
     */
    public function __construct(
        Context $context,
        ScopeConfigInterface $scopeConfig,
        Creditmemo $creditmemo = null,
        array $data = []
    ) {
        $this->_creditmemo = $creditmemo;
        $this->_scopeConfig = $scopeConfig;
        parent::__construct($context, $data);
    }

    /**
     * Get data (totals) source model
     *
     * @return DataObject|null
     */
    public function getSource()
    {
        if (!$this->_source && $this->_creditmemo) {
            $this->_source = $this->_creditmemo;
        }
        return $this->_source;
    }

    /**
     * Get store
     *
     * @return \Magento\Store\Api\Data\StoreInterface|null
     */
    public function getStore()
    {
        if ($this->_creditmemo) {
            return $this->_creditmemo->getStore();
        }
        return null;
    }

    /**
     * @return Creditmemo|null
     */
    public function getCreditmemo()
    {
        return $this->_creditmemo;
    }
    public function initTotals()
    {
        $parent = $this->getParentBlock();
        $creditmemo = $parent->getSource();
        
        if ($creditmemo && $creditmemo->getLaberPrice() !== null && $creditmemo->getLaberPrice() != 0) {
            
            $LaberPrice = new DataObject(
                [
                    'code' => 'laber_price',
                    'strong' => false,
                    'value' => $creditmemo->getLaberPrice(),
                    'label' => 'Laber Price',
                ]
            );
            $parent->addTotal($LaberPrice, 'subtotal');
        }
        return $this;
    }
}
