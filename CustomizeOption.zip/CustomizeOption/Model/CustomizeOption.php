<?php

namespace Kitchen365\CustomizeOption\Model;

use Magento\Quote\Model\Quote\Address\Total\AbstractTotal;
use Magento\Quote\Model\Quote;
use Magento\Quote\Api\Data\ShippingAssignmentInterface;
use Magento\Quote\Model\Quote\Address\Total;
use Magento\Quote\Model\QuoteValidator;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Kitchen365\CustomizeOption\Model\Product\Type\Price;
use Magento\Customer\Api\GroupRepositoryInterface;
use Magento\Tax\Model\Calculation;
use Magento\Quote\Model\ResourceModel\Quote\Item\Collection;

class CustomizeOption extends AbstractTotal
{
    protected $quoteValidator;
    protected $scopeConfig;
    protected $priceModel;
    protected $groupRepository;
    protected $taxCalculation;
    protected $quoteItemCollection;


    public function __construct(
        QuoteValidator $quoteValidator,
        ScopeConfigInterface $scopeConfig,
        Price $priceModel,
        GroupRepositoryInterface $groupRepository,
        Calculation $taxCalculation,
        Collection $quoteItemCollection
    ) {
        $this->quoteItemCollection = $quoteItemCollection;
        $this->quoteValidator = $quoteValidator;
        $this->scopeConfig = $scopeConfig;
        $this->priceModel = $priceModel;
        $this->groupRepository = $groupRepository;
        $this->taxCalculation = $taxCalculation;

    }

    public function collect(
        Quote $quote,
        ShippingAssignmentInterface $shippingAssignment,
        Total $total
    ) {
        parent::collect($quote, $shippingAssignment, $total);
        $laberPriceTotal = 0;
        // print_r(get_class_methods($total));
        // die;
        foreach ($quote->getAllItems() as $item) {
            $product = $item->getProduct();
            $finalPrice = $item->getPrice();

            if ($item->getDiscountPercent()) {
                $finalPrice -= (($finalPrice * $item->getDiscountPercent()) / 100);
            } elseif ($item->getDiscountAmount()) {
                $finalPrice -= ($item->getDiscountAmount() / $item->getQty());
            }
            $product->setData("final_price", $finalPrice);
            $itemCustomPrice = $this->priceModel->getFinalPriceWithCuOptions($item->getQty(), $product);
            $item->setLaberPrice($itemCustomPrice);
            $itemCustomPrice *= $item->getQty();
            $laberPriceTotal += $itemCustomPrice;
        }
        // $tax = $this->calculateLaborPriceTax($quote, $laberPriceTotal);
        $quote->setLaberPrice($laberPriceTotal);
        $tax = $this->taxCalculation->calcTaxAmount(
            $laberPriceTotal,
            $this->getTaxRate($quote),
            false,
            $quote->getStore()
        );
        // echo $tax;
        // die;
        
        $total->addTotalAmount('tax', $tax);
        $total->addBaseTotalAmount('tax', $tax);
        
        $total->setTotalAmount('laber_price', $laberPriceTotal);
        $total->setBaseTotalAmount('laber_price', $laberPriceTotal);
        
       

        return $this;
    }
    // protected function calculateLaborPriceTax(Quote $quote, $laberPriceTotal)
    // {
    //     $taxRate = $this->getTaxRate($quote);
    //     return ($laberPriceTotal * $taxRate) / 100;
    // }

    protected function getTaxRate(Quote $quote)
    {
        $address = $quote->getShippingAddress();
        $store = $quote->getStore();
        $customerGroupId = $quote->getCustomer()->getGroupId();
        if ($customerGroupId === null) {
            $customerGroupId = \Magento\Customer\Model\Group::NOT_LOGGED_IN_ID;
        }

        $customerTaxClassId = $this->groupRepository->getById($customerGroupId)->getTaxClassId();
        $taxRateRequest = $this->taxCalculation->getRateRequest($address, null, null, $store);
        $taxRateRequest->setCustomerClassId($customerTaxClassId);
        
        // You should use the tax class ID associated with your products or custom service
        $productTaxClassId = $this->scopeConfig->getValue(
            'tax/classes/default_product_tax_class',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE,
            $store
        );
        $taxRateRequest->setProductClassId($productTaxClassId);
        $taxRate = $this->taxCalculation->getRate($taxRateRequest);
        return $taxRate;
    }

    protected function clearValues(Total $total)
    {
        $total->setTotalAmount('subtotal', 0);
        $total->setBaseTotalAmount('subtotal', 0);
        $total->setTotalAmount('tax', 0);
        $total->setBaseTotalAmount('tax', 0);
        $total->setTotalAmount('discount_tax_compensation', 0);
        $total->setBaseTotalAmount('discount_tax_compensation', 0);
        $total->setTotalAmount('shipping_discount_tax_compensation', 0);
        $total->setBaseTotalAmount('shipping_discount_tax_compensation', 0);
        $total->setSubtotalInclTax(0);
        $total->setBaseSubtotalInclTax(0);
    }

    public function fetch(Quote $quote, Total $total)
    {
        $laberPriceTotal = $quote->getLaberPrice();

        return [
            'code' => 'laber_price',
            'title' => $this->getLabel(),
            'value' => $laberPriceTotal
        ];
    }

    public function getLabel()
    {
        return __('Laber Price');
    }
}
