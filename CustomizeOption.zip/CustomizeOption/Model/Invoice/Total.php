<?php

namespace Kitchen365\CustomizeOption\Model\Invoice;

use Magento\Sales\Model\Order\Invoice\Total\AbstractTotal;

class Total extends AbstractTotal
{
    /**
     * Collect totals process.
     *
     * @param \Magento\Sales\Model\Order\Invoice $invoice
     * @return $this
     */
    public function collect(\Magento\Sales\Model\Order\Invoice $invoice)
    {
        parent::collect($invoice);
        $order = $invoice->getOrder();
        $LaberPrice = $order->getLaberPrice();
        $invoice->setLaberPrice($LaberPrice);

        return $this;
    }
}
