<?php

namespace Kitchen365\CustomizeOption\Model\Creditmemo;

use Magento\Sales\Model\Order\Creditmemo\Total\AbstractTotal;

class Total extends AbstractTotal
{
    /**
     * Collect totals process.
     *
     * @param \Magento\Sales\Model\Order\Creditmemo $creditmemo
     * @return $this
     */
    public function collect(\Magento\Sales\Model\Order\Creditmemo $creditmemo)
    {
        parent::collect($creditmemo);

        $order = $creditmemo->getOrder();
        $LaberPrice = $order->getLaberPrice();

        $creditmemo->setLaberPrice($LaberPrice);

        return $this;
    }
}
