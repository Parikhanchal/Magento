<?php

namespace Kitchen365\CustomizeOption\Model\Sales\Pdf;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Sales\Model\Order\Pdf\Total\DefaultTotal;

class LaberPrice extends DefaultTotal
{
    /**
     * @var ScopeConfigInterface
     */
    protected $_scopeConfig;


    public function __construct(
        ScopeConfigInterface $scopeConfig
    ) {
        $this->_scopeConfig = $scopeConfig;
    }

    public function getTotalsForDisplay(): array
    {
        $laberprice = $this->getOrder()->getlaberPrice();
        if ($laberprice == 0) {
            return [];
        }
        
        $amountInclTax = $this->getOrder()->formatPriceTxt($laberprice);
        $fontSize = $this->getFontSize() ? $this->getFontSize() : 7;
    
        return [
            [
                'amount' => $this->getAmountPrefix() . $amountInclTax,
                'label' => 'Laber Price',
                'font_size' => $fontSize,
            ]
        ];
    }
}
