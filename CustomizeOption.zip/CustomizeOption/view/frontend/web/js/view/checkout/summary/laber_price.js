define([
    'Magento_Checkout/js/view/summary/abstract-total',
    'Magento_Checkout/js/model/quote',
    'Magento_Checkout/js/model/totals',
    'ko',
    'jquery'
], function (Component, quote, totals, ko, $) {
    'use strict';

    return Component.extend({
        defaults: {
            template: 'Kitchen365_CustomizeOption/checkout/summary/laber_price'
        },
        
        totals: quote.getTotals(),

        getTitle: function () {
            var Title = '';
            if(totals && typeof totals.getSegment("laber_price") !== "undefined" && typeof totals.getSegment("laber_price").title !== "undefined") {
                Title = totals.getSegment("laber_price").title;
            }
            return Title;
        },

        getValue: function () {
            var laberPrice = 0;
            if(totals && typeof totals.getSegment("laber_price") !== "undefined" && typeof totals.getSegment("laber_price").value !== "undefined") {
                laberPrice = totals.getSegment("laber_price").value;
            }
            return this.getFormattedPrice(laberPrice);
        },

        isDisplayed: function () {
            return this.getPureValue() !== 0;
        },
        

        getPureValue: function () {
            var laberPrice = 0;
            if(totals && typeof totals.getSegment("laber_price") !== "undefined" && typeof totals.getSegment("laber_price").value !== "undefined") {
                laberPrice = totals.getSegment("laber_price").value;
            }
            return laberPrice;
        }
    });
});
