define([
    'Magento_Checkout/js/view/summary/abstract-total',
    'Magento_Checkout/js/model/quote',
    'Magento_Checkout/js/model/totals',
    'ko',
    'jquery'
], function (Component, quote, totals, ko, $) {
    'use strict';

    return Component.extend({
        defaults: {
            template: 'Kitchen365_PaymentFee/checkout/summary/fee'
        },
        
        totals: quote.getTotals(),

        getTitle: function () {
            var feeTitle = '';
            if(totals && typeof totals.getSegment("fee") !== "undefined" && typeof totals.getSegment("fee").title !== "undefined") {
                feeTitle = totals.getSegment("fee").title;
            }
            return feeTitle;
        },

        getValue: function () {
            var feeValue = 0;
            if(totals && typeof totals.getSegment("fee") !== "undefined" && typeof totals.getSegment("fee").value !== "undefined") {
                feeValue = totals.getSegment("fee").value;
            }
            return this.getFormattedPrice(feeValue);
        },

        isDisplayed: function () {
            return this.getPureValue() !== 0;
        },
        

        getPureValue: function () {
            var feeValue = 0;
            if(totals && typeof totals.getSegment("fee") !== "undefined" && typeof totals.getSegment("fee").value !== "undefined") {
                feeValue = totals.getSegment("fee").value;
            }
            return feeValue;
        }
    });
});
