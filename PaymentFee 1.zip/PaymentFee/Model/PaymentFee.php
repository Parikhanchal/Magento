<?php

namespace Kitchen365\PaymentFee\Model;

use Magento\Quote\Model\Quote\Address\Total\AbstractTotal;
use Magento\Quote\Model\Quote;
use Magento\Quote\Api\Data\ShippingAssignmentInterface;
use Magento\Quote\Model\Quote\Address\Total;
use Magento\Quote\Model\QuoteValidator;
use Magento\Framework\App\Config\ScopeConfigInterface;

class PaymentFee extends AbstractTotal
{
    CONST XML_PATH_PAYMENT_FEE_TITLE = 'payment_section/paymentfee/title';
    CONST XML_PATH_PAYMENT_FEE_AMOUNT = 'payment_section/paymentfee/fee_percentage';
    protected $quoteValidator;
    protected $scopeConfig;

    public function __construct(
        QuoteValidator $quoteValidator,
        ScopeConfigInterface $scopeConfig
    ) {
        $this->quoteValidator = $quoteValidator;
        $this->scopeConfig = $scopeConfig;
    }

    public function collect(
        Quote $quote,
        ShippingAssignmentInterface $shippingAssignment,
        Total $total
    ) {
        parent::collect($quote, $shippingAssignment, $total);
        $subtotal = $quote->getSubtotal();
        $paymentFeePercentage = $this->getPaymentFeePercentage();
        $balance = ($subtotal * $paymentFeePercentage / 100);

        $quote->setFee($balance);
        $total->setBaseFee($balance);
        $total->setGrandTotal($total->getGrandTotal() + $balance);
        $total->setBaseGrandTotal($total->getBaseGrandTotal() + $balance);

        return $this;
    }

    protected function clearValues(Total $total)
    {
        $total->setTotalAmount('subtotal', 0);
        $total->setBaseTotalAmount('subtotal', 0);
        $total->setTotalAmount('tax', 0);
        $total->setBaseTotalAmount('tax', 0);
        $total->setTotalAmount('discount_tax_compensation', 0);
        $total->setBaseTotalAmount('discount_tax_compensation', 0);
        $total->setTotalAmount('shipping_discount_tax_compensation', 0);
        $total->setBaseTotalAmount('shipping_discount_tax_compensation', 0);
        $total->setSubtotalInclTax(0);
        $total->setBaseSubtotalInclTax(0);
    }

    public function fetch(Quote $quote, Total $total)
    {
        $subtotal = $quote->getSubtotal();
        $paymentFeePercentage = $this->getPaymentFeePercentage();
        $balance = ($subtotal * $paymentFeePercentage / 100);
        // if ($balance == 0) {
        //     return [];
        // }
        return [
            'code' => 'fee',
            'title' => $this->getLabel(),
            'value' => $balance
        ];
    }

    public function getLabel()
    {
        $label = $this->scopeConfig->getValue(self::XML_PATH_PAYMENT_FEE_TITLE, \Magento\Store\Model\ScopeInterface::SCOPE_STORE);    
        return __($label);
    }


    public function getPaymentFeePercentage()
    {
        $feePercentage = $this->scopeConfig->getValue(
            self::XML_PATH_PAYMENT_FEE_AMOUNT,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
       
        return $feePercentage ? (float)$feePercentage : 0;
    }
}
