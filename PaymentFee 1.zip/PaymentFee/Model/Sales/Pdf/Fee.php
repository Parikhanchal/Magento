<?php

namespace Kitchen365\PaymentFee\Model\Sales\Pdf;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Sales\Model\Order\Pdf\Total\DefaultTotal;

class Fee extends DefaultTotal
{
    const XML_PATH_PAYMENT_FEE_TITLE = 'payment_section/paymentfee/title';

    /**
     * @var ScopeConfigInterface
     */
    protected $_scopeConfig;

    /**
     * Fee constructor.
     * @param ScopeConfigInterface $scopeConfig
     */
    public function __construct(
        ScopeConfigInterface $scopeConfig
    ) {
        $this->_scopeConfig = $scopeConfig;
    }

    /**
     * Get array of arrays with totals information for display in PDF
     * array(
     *  $index => array(
     *      'amount'   => $amount,
     *      'label'    => $label,
     *      'font_size'=> $font_size
     *  )
     * )
     * @return array
     */
    public function getTotalsForDisplay(): array
    {
        $fee = $this->getOrder()->getFee();
        if ($fee == 0) {
            return [];
        }
        
        $amountInclTax = $this->getOrder()->formatPriceTxt($fee);
        $fontSize = $this->getFontSize() ? $this->getFontSize() : 7;
        $label = $this->_scopeConfig->getValue(
            self::XML_PATH_PAYMENT_FEE_TITLE,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE,
            $this->getOrder()->getStore()
        );

        return [
            [
                'amount' => $this->getAmountPrefix() . $amountInclTax,
                'label' => $label,
                'font_size' => $fontSize,
            ]
        ];
    }
}
