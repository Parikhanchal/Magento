<?php

namespace Kitchen365\PaymentFee\Model\Creditmemo;

use Magento\Sales\Model\Order\Creditmemo\Total\AbstractTotal;

class Total extends AbstractTotal
{
    /**
     * Collect totals process.
     *
     * @param \Magento\Sales\Model\Order\Creditmemo $creditmemo
     * @return $this
     */
    public function collect(\Magento\Sales\Model\Order\Creditmemo $creditmemo)
    {
        parent::collect($creditmemo);

        $order = $creditmemo->getOrder();
        $paymentFee = $order->getFee();

        $creditmemo->setFee($paymentFee);
        $creditmemo->setGrandTotal($creditmemo->getGrandTotal() + $paymentFee);
        $creditmemo->setBaseGrandTotal($creditmemo->getBaseGrandTotal() + $paymentFee);

        return $this;
    }
}
