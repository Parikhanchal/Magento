<?php
namespace Kitchen365\PaymentFee\Block;

use Magento\Framework\View\Element\Template\Context;
use Magento\Framework\View\Element\Template;
use Kitchen365\PaymentFee\Helper\Data as PaymentFeeHelper;

class Fee extends Template
{
    protected $paymentFeeHelper;

    public function __construct(
        Context $context,
        PaymentFeeHelper $paymentFeeHelper,
        array $data = []
    ) {
        $this->paymentFeeHelper = $paymentFeeHelper;
        parent::__construct($context, $data);
    }

    /**
     * Get payment fee title for JavaScript configuration
     *
     * @return string
     */
    public function getPaymentFeeTitle()
    {
        return $this->paymentFeeHelper->getPaymentFeeTitle();
    }
}
