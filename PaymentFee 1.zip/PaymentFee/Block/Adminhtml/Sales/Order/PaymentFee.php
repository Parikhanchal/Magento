<?php

namespace Kitchen365\PaymentFee\Block\Adminhtml\Sales\Order;

use Magento\Sales\Model\Order;
use Magento\Framework\View\Element\Template\Context;
use Magento\Tax\Model\Config;
use Magento\Framework\App\Config\ScopeConfigInterface;

class PaymentFee extends \Magento\Framework\View\Element\Template
{
    const XML_PATH_PAYMENT_FEE_TITLE = 'payment_section/paymentfee/title';

    /**
     * Tax configuration model
     *
     * @var Config
     */
    protected $_config;

    /**
     * @var Order
     */
    protected $_order;

    /**
     * @var \Magento\Framework\DataObject
     */
    protected $_source;

    /**
     * @var ScopeConfigInterface
     */
    protected $_scopeConfig;

    /**
     * @param Context $context
     * @param ScopeConfigInterface $scopeConfig
     * @param array $data
     */
    public function __construct(
        Context $context,
        ScopeConfigInterface $scopeConfig,
        array $data = []
    ) {
        $this->_scopeConfig = $scopeConfig;
        parent::__construct($context, $data);
    }

    /**
     * Check if we need to display full tax total info
     *
     * @return bool
     */
    public function displayFullSummary()
    {
        return true;
    }

    /**
     * Get data (totals) source model
     *
     * @return \Magento\Framework\DataObject
     */
    public function getSource()
    {
        return $this->_source;
    }

    /**
     * Get store
     *
     * @return \Magento\Store\Api\Data\StoreInterface
     */
    public function getStore()
    {
        return $this->_order->getStore();
    }

    /**
     * Get order
     *
     * @return Order
     */
    public function getOrder()
    {
        return $this->_order;
    }

    /**
     * Get label properties
     *
     * @return array
     */
    public function getLabelProperties()
    {
        return $this->getParentBlock()->getLabelProperties();
    }

    /**
     * Get value properties
     *
     * @return array
     */
    public function getValueProperties()
    {
        return $this->getParentBlock()->getValueProperties();
    }

    /**
     * Initialize all order totals related to tax
     *
     * @return $this
     */
    public function initTotals()
    {
        $parent = $this->getParentBlock();
        $this->_order = $parent->getOrder();
        $this->_source = $parent->getSource();

        $feeValue = $this->_order->getFee();

        if ($feeValue !== null && $feeValue != 0) {
            $label = $this->_scopeConfig->getValue(
                self::XML_PATH_PAYMENT_FEE_TITLE,
                \Magento\Store\Model\ScopeInterface::SCOPE_STORE
            );

            $fee = new \Magento\Framework\DataObject(
                [
                    'code' => 'fee',
                    'value' => $feeValue,
                    'label' => $label,
                ]
            );

            $parent->addTotal($fee, 'fee');
        }

        return $this;
    }
}
