<?php

namespace Kitchen\Payment\Model\Adminhtml\System\Config\Source\Customer;

class Group implements \Magento\Framework\Option\ArrayInterface
{
protected $_options;
protected $_groupCollectionFactory; 

public function __construct(\Magento\Customer\Model\ResourceModel\Group\CollectionFactory $groupCollectionFactory)
{
    $this->_groupCollectionFactory = $groupCollectionFactory;
}

/**
 * @return array
 */
public function toOptionArray()
{
    if (!$this->_options) {
        $this->_options = $this->_groupCollectionFactory->create()->loadData()->toOptionArray();
    }
    return $this->_options;
}
}