<?php

namespace Cp\User\Helper;
use \Magento\Framework\App\Helper\AbstractHelper;

class Data extends AbstractHelper
{
       public function getweb()
       {
        return "Helper File";
       }
}
