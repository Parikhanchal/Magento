<?php 
namespace Cp\User\Model;
 
 
class PostManagement {

	/**
	 * {@inheritdoc}
	 */
	public function getPost()
	{
		return 'hello';
    }
}