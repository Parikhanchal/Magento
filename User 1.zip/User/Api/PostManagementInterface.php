<?php 
namespace Cp\User\Api;
 
 
interface PostManagementInterface {


	/**
	 * GET for Post api
	 * @return string
	 */
	
	public function getPost();
}
