<?php

namespace Kitchen\NewMail\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Quote\Model\QuoteRepository;
use Psr\Log\LoggerInterface;
use Magento\Framework\Mail\Template\TransportBuilder;
use Magento\Framework\Translate\Inline\StateInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Message\ManagerInterface;

class SendMail implements ObserverInterface
{
    protected $quoteRepository;
    protected $logger;
    protected $transportBuilder;
    protected $storeManager;
    protected $inlineTranslation;
    protected $messageManager;

    public function __construct(
        QuoteRepository $quoteRepository,
        LoggerInterface $logger,
        TransportBuilder $transportBuilder,
        StateInterface $inlineTranslation,
        StoreManagerInterface $storeManager,
        ManagerInterface $messageManager
    ) {
        $this->quoteRepository = $quoteRepository;
        $this->logger = $logger;
        $this->transportBuilder = $transportBuilder;
        $this->inlineTranslation = $inlineTranslation;
        $this->storeManager = $storeManager;
        $this->messageManager = $messageManager;
    }

    public function execute(Observer $observer)
    {
        try {

            // $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
            // $senderEmail = $this->scopeConfig->getValue('kitchen_email/try_email/kitchen_reciver_email', $storeScope);
            // $recipientEmail = $this->scopeConfig->getValue('kitchen_email/try_email/kitchen_send_email', $storeScope);
            
            // echo 11;
            // die;
            // $templateVars = [];  
            
             // Get quote ID from the observer event
             $quoteId = $observer->getEvent()->getData('quote_id');
            
             // Print or log the quote ID for debugging
            //  $this->logger->info('Quote ID: ' . $quoteId);
            // var_dump($quoteId);
            // die;

             
             // Prepare template variables
             $templateVars = [
                 'quote_id' => $quoteId,
                 // Add more variables as needed
             ];
             
             // Suspend inline translation while sending email
            $this->inlineTranslation->suspend();
            $transport = $this->transportBuilder
                ->setTemplateIdentifier('quote_email_template') // Use the template ID from email_templates.xml
                ->setTemplateOptions([
                    'area' => \Magento\Framework\App\Area::AREA_FRONTEND,
                    'store' => $this->storeManager->getStore()->getId()
                    ])
                ->setTemplateVars($templateVars)
                ->setFrom(['email' => 'Aanchal@g.com', 'name' => 'Your Store'])
                ->addTo('new@gmail.com')
                ->getTransport();
                // print_r($transport);
                // die;
                
            $transport->sendMessage();
            
            $this->inlineTranslation->resume();
            $this->messageManager->addSuccessMessage(__('Email sent successfully.'));
        } catch (\Exception $e) {
            $this->inlineTranslation->resume();
            $this->logger->error($e->getMessage());
            $this->messageManager->addErrorMessage(__('Unable to send email.'));
        }
    }
}
