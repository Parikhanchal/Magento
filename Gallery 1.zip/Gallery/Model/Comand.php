<?php

namespace Kitchen\Gallery\Model;

use \Symfony\Component\Console\Command\Command;
use \Symfony\Component\Console\Input\InputInterface;
use \Symfony\Component\Console\Output\OutputInterface;
use Kitchen\Gallery\Model\GalleryFactory;

class Comand extends Command
{
    protected $_galleryFactory;

    public function __construct(
        GalleryFactory $_galleryFactory
    ) {
        $this->_galleryFactory = $_galleryFactory;
        parent::__construct();
    }


    protected function configure()
    {
        $this->setName('kitchen:cleans')
        ->setDescription('Kitchen Gallery Cleans Commands!');

        parent::configure();
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        
        $varCustomer = $this->_galleryFactory->create();
        $varCollection = $varCustomer->getCollection();
        
        foreach ($varCollection as $row) {
            $output->writeln('Gallery ID is: ' . $row->getId())."<br>";
        }

        return 1;
    }
}