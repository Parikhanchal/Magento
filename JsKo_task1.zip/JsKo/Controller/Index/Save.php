<?php
namespace Task\JsKo\Controller\Index;
 
use Magento\Framework\App\Action\Context;
use Magento\Framework\Controller\Result\JsonFactory;
use Task\JsKo\Model\UserFactory;
 
class Save extends \Magento\Framework\App\Action\Action
{
    protected $_jsonFactory;
    protected $_userFactory;
 
    public function __construct(
        Context $context,
        JsonFactory $jsonFactory,
        UserFactory $userFactory
    ) {
        $this->_userFactory = $userFactory;
        $this->_jsonFactory = $jsonFactory;
        parent::__construct($context);
    }
 
    public function execute()
    {
        $result = $this->_jsonFactory->create();
        
        try {
            $jsonData = $this->getRequest()->getContent();
            $data = json_decode($jsonData, true);
 
            // Validate the required fields
            if (!isset($data['name']) || !isset($data['email'])) {
                throw new \InvalidArgumentException('Name and Email are required fields.');
            }
 
            $name = $data['name'];
            $gender = isset($data['gender']) ? $data['gender'] : '';
            $email = $data['email'];
            $image = isset($data['image']) ? $data['image'] : '';
            $status = isset($data['status']) ? $data['status'] : '';
 
            $user = $this->_userFactory->create();
            $user->setName($name);
            $user->setEmail($email);
            $user->setGender($gender); // Assuming you have a method like this in your model
            $user->setImage($image);   // Similarly, assuming methods for image and status
            $user->setStatus($status);
 
            $user->save();
 
            // return $result->setData([
            //     'success' => true,
            //     'data' => $user->getData()
            // ]);
        } catch (\Exception $e) {
            return $result->setData([
                'success' => false,
                'error' => $e->getMessage()
            ]);
        }
    }
}
 