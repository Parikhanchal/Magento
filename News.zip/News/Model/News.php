<?php

namespace Kitchen\News\Model;

class News extends \Magento\Framework\Model\AbstractModel
{
    public function _construct()
    {
        $this->_init(\Kitchen\News\Model\ResourceModel\News::class);
    }
}
