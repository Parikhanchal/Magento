<?php

namespace Kitchen\News\Model\ResourceModel\News;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    protected $_idFieldName = 'news_id';
    protected function _construct()
    {
        $this->_init(
            \Kitchen\News\Model\News::class,
            \Kitchen\News\Model\ResourceModel\News::class
        );
    }
}
