<?php

namespace Kitchen\News\Model;

use Kitchen\News\Model\NewsFactory;
use Magento\Framework\Exception\LocalizedException;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;

class NewsCommand extends Command
{
    /**
     * @var NewsFactory
     */
    protected $newsFactory;

    /**
     * @var ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * Constructor.
     *
     * @param NewsFactory $newsFactory
     * @param ScopeConfigInterface $scopeConfig
     * @param string|null $name
     */
    public function __construct(NewsFactory $newsFactory, ScopeConfigInterface $scopeConfig, string $name = null)
    {
        parent::__construct($name);
        $this->newsFactory = $newsFactory;
        $this->scopeConfig = $scopeConfig;
    }

    protected function configure()
    {
        $this->setName('kitchen:news')
             ->setDescription('Deletes all news entries from the system.');
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        if ($this->scopeConfig->getValue('newsinfo/newsgrp/enable') == 1) {
            $newsModel = $this->newsFactory->create();
            $newsCollection = $newsModel->getCollection();
            $count = 0;

            foreach ($newsCollection as $news) {
                try {
                    $news->delete();
                    $count++;
                } catch (LocalizedException $e) {
                    $output->writeln('Error deleting news with ID ' . $news->getId() . ': ' . $e->getMessage());
                }
            }

            $output->writeln($count . ' news entries have been deleted.');
            return Command::SUCCESS;  
        } else {
            $output->writeln('Kitchen News Command: For Delete All Record Please Enabled in Admin');
            return Command::FAILURE;
        }
    }
}
