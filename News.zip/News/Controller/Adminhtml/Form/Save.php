<?php
declare(strict_types=1);

namespace Kitchen\News\Controller\Adminhtml\Form;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Backend\Model\View\Result\Redirect;
use Kitchen\News\Model\NewsFactory;
use Magento\Framework\App\Action\HttpPostActionInterface;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\Exception\LocalizedException;

class Save extends Action implements HttpPostActionInterface
{
    /**
     * @var NewsFactory
     */
    private $newsFactory;

    /**
     * Constructor
     *
     * @param Context $context
     * @param NewsFactory $newsFactory
     */
    public function __construct(
        Context $context,
        NewsFactory $newsFactory
    ) {
        parent::__construct($context);
        $this->notificationFactory = $newsFactory;
    }

    /**
     * Save action
     *
     * @return ResultInterface
     */
    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        $data = $this->getRequest()->getPostValue();
        // print_r($data);
        if ($data) {
            $id = !empty($data['news_id']) ? (int)$data['news_id'] : null;
            $model = $this->notificationFactory->create();

            if ($id) {
                $model->load($id);
                if (!$model->getId()) {
                    $this->messageManager->addErrorMessage(__('This News no longer exists.'));
                    return $resultRedirect->setPath('news/grid/index');
                }
            }

            try {
                $model->setTitle($data['title']);
                $model->setDescription($data['description']);
                $model->setIsActive($data['is_active']);
                $model->setSortorder($data['sortorder']);
                $customerGroup = implode(',', $data['customer_group']);
                $model->setCustomerGroup($customerGroup);

                if (!empty($data['news_banner'][0]['name'])) {
                   
                    $imageName = $data['news_banner'][0]['name'];

                    $model->setNewsBanner($imageName);
                  
                }

                $model->save();
                $this->messageManager->addSuccessMessage(__('News data has been saved.'));
            } catch (LocalizedException $e) {
                $this->messageManager->addErrorMessage($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addErrorMessage(__('Something went wrong while saving the News data.'));
            }

            $this->_getSession()->setFormData($data);
        }

        return $resultRedirect->setPath('news/grid/index');
    }
}
