<?php

namespace Kitchen\News\Ui\Component\Listing\Column;

use Magento\Ui\Component\Listing\Columns\Column;
use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\UrlInterface;

class Thumbnail extends Column
{

    const NAME = 'news_banner';

    const ALT_FIELD = 'Image';

    protected $storeManager;
    protected $urlBuilder;

    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        StoreManagerInterface $storeManager,
        UrlInterface $urlBuilder,
        array $components = [],
        array $data = []
    )
    {
        $this->storeManager = $storeManager;
        $this->urlBuilder = $urlBuilder; 
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }

    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {
            $fieldName = $this->getData('name');
            foreach ($dataSource['data']['items'] as & $item) {
                $filename = $item[$fieldName];
                $item[$fieldName . '_src'] = $this->getImage($filename);
                $item[$fieldName . '_alt'] = $this->getAlt($item) ?: $filename;
                $item[$fieldName . '_orig_src'] = $this->getImage($filename);
                
                $item[$fieldName . '_link'] = $this->urlBuilder->getUrl(
                    'news/form/index',
                    ['news_id' => $item['news_id']]
                );
            }
        }   

        return $dataSource;
    }

    public function getImage($imagePath){
        if($imagePath!=""){
            return $this->storeManager->getStore()->getBaseUrl(UrlInterface::URL_TYPE_MEDIA).'/Kitchen/news/'.$imagePath;
        }
        return "";
    }

    protected function getAlt($row)
    {
        $altField = $this->getData('config/altField') ?: self::ALT_FIELD;
        return isset($row[$altField]) ? $row[$altField] : null;
    }
}
