<?php

namespace Kitchen\Product\Model\ResourceModel\Customer;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    protected $_idFieldName = 'customer_id';
    protected function _construct()
    {
        $this->_init(
            \Kitchen\Product\Model\Customer::class,
            \Kitchen\Product\Model\ResourceModel\Customer::class
        );
    }
}

