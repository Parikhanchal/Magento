<?php
 session_start();
    class Database 
    {
		protected $conn;
		public function __construct()
        {
			$servername = "localhost";
			$username = "root";
			$password = "toor1";
			$dbName = "project";
			$this->conn = new mysqli($servername, $username, $password, $dbName);
			if ($this->conn->connect_error) 
            {
				die("Connection failed: " . $this->conn->connect_error);
			}	
		}
    }
    class Category extends Database
    {
        public function create()
        {
            $name = $_POST['name'];
            $sorting = $_POST['sorting'];

            $sql = "INSERT INTO category (name,sort_order) VALUES ('$name','$sorting')";
            $result = $this->conn->query($sql);
            if($result) {
                $_SESSION['message'] = 'Product inserted successfully';
               header("location:form.php");
                exit();
            } else {
                $_SESSION['message'] = "Error inserting data" .$this->conn->error;
            }
            return $result;
        }

        public function select()
        {
            $sql = "SELECT * FROM category";
            $result = $this->conn->query($sql);
            return $result;
        }

        public function update($name,$sorting)
        {
            $id = $_GET['id'];
            $name = $_POST["name"];
            $sorting = $_POST["sorting"];
            
            $sql = "UPDATE category SET name = '$name', sort_order = '$sorting' WHERE entity_id = '$id'";
            $result = $this->conn->query($sql);
            
            if( $result) 
            {
                
                $_SESSION['message'] = "update category";
                // echo "<script>window.location.href='form.php';</script>";
                header("location:form.php");
                exit();
            } 
            else 
            {
                $_SESSION['message'] = "Error update data" .$this->conn->error;
            }
            return $result;
        }

        public function fetch($id)
        {
            $sql = "SELECT * FROM category WHERE entity_id = '$id'";
            $result = $this->conn->query($sql);
            return $result;
        }

        public function delete($id)
        {
            $sql = "DELETE FROM category WHERE entity_id = '$id'";
            $result = $this->conn->query($sql);  
            return $result;
        }
    }
?>


<?php
if($_SERVER["REQUEST_METHOD"] == "POST")
{
    if(isset($_POST["submit"])){
        $category = new Category();
        $category->create();
    }
}
?>

<?php
if (isset($_POST['update']))
{
    $category = new Category();
    $category->update($name,$sorting);
}
?>