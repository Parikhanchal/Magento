<?php

    echo  one;
    
?>