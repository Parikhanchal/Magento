<?php
    namespace Kitchen\Product\Block;
 
    use Kitchen\Product\Model\GalleryFactory;
    use Magento\Framework\UrlInterface;
    use Magento\Framework\View\Element\Template\Context;
    use Magento\Framework\App\Config\ScopeConfigInterface;
 
    class Promotion extends \Magento\Framework\View\Element\Template
    {
        protected $galleryFactory;
        protected $urlBuilder;
        protected $scopeConfig;
 
        public function __construct(
            Context $context,
            ScopeConfigInterface $scopeConfig,
            GalleryFactory $galleryFactory,
            UrlInterface $urlBuilder
    )
    {
        $this->galleryFactory = $galleryFactory;
        $this->urlBuilder = $urlBuilder;
        $this->scopeConfig = $scopeConfig;
        parent::__construct($context);
    }

    

    public function getDisplayName()
    {
        return $this->scopeConfig->getValue('promotion/general_one/name', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    public function getDisplayDescription()
    {
        return $this->scopeConfig->getValue('promotion/general_one/description', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    public function getStartDate()
    {
        return $this->scopeConfig->getValue('promotion/general_one/startDate', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    public function getEndDate()
    {
        return $this->scopeConfig->getValue('promotion/general_one/endDate', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

    public function isActive()
    {
        return $this->scopeConfig->getValue('promotion/general_one/isActive', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }
}
