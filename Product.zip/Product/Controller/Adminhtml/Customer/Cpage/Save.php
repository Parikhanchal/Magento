<?php
// declare(strict_types=1);

namespace Kitchen\Product\Controller\Adminhtml\Customer;

use Magento\Backend\App\Action;
use Magento\Backend\Model\View\Result\Redirect;
use Kitchen\Product\Model\CustomerFactory;
use Magento\Framework\App\Action\HttpPostActionInterface;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\Exception\LocalizedException;

class Save extends Action implements HttpPostActionInterface
{
    /**
     * @var CustomerFactory
     */
    private $customerFactory;

    /**
     * @param Action\Context $context
     * @param CustomerFactory $customerFactory
     */
    public function __construct(
        Action\Context $context,
        CustomerFactory $customerFactory
    ) {
        parent::__construct($context);
        $this->customerFactory = $customerFactory;
    }

    /**
     * Save action
     *
     * @return ResultInterface
     */
    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        $data = $this->getRequest()->getPostValue();
        
        if ($data) {

            try {
                // Check if customer_id exists in the data
                if (!empty($data['customer_id'])) {
                    // Load existing customer model if customer_id is present
                    $model = $this->customerFactory->create()->load($data['customer_id']);
                } else {
                    // Create a new customer model if customer_id is not present
                    $model = $this->customerFactory->create();
                }

                // $model = $this->CustomerFactory->create();
                // $model->setCustomerId($data['customer_id']);
                $model->setFirstName($data['first_name']);
                $model->setLastName($data['last_name']);
                $model->setEmail($data['email']);
                $model->setGender($data['gender']);
                $model->setBirthDate($data['birth_date']);
                $model->setProfileImage($data['profile_image']);
                $model->setAddress($data['address']);
                $model->setHobbies($data['hobbies']);
                $model->setNewsletterSubscription($data['newsletter_subscription']);
                $model->setIsActive($data['is_active']);
                
                $model->save();
                $this->messageManager->addSuccessMessage(__('Customer has been saved.'));
            }
            
            catch (LocalizedException $e) {
                $this->messageManager->addErrorMessage($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addErrorMessage(__('Something went wrong while saving the user data.'));
            }
     
            // Redirect back to the customer page
            return $resultRedirect->setPath('prod/customer/index');
        }
     
        // If no data is available, redirect back to the customer page
        return $resultRedirect->setPath('prod/customer/index');
    }


            else {
                $this->messageManager->addErrorMessage(__('Something went wrong while saving the data.'));
            }

            $this->_getSession()->setFormData($data);
            return $resultRedirect->setPath('prod/customer/index');
        }
}




 
// // namespace Kitchen\News\Controller\Adminhtml\Customer;
 
// use Magento\Framework\App\Action\Action;
// use Magento\Framework\App\Action\Context;
// // use Kitchen\News\Model\CustomerFactory;
 
// class Save extends Action
// {
//     protected $customerFactory;
 
//     public function __construct(
//         Context $context,
//         CustomerFactory $customerFactory
//     ) {
//         $this->customerFactory = $customerFactory;
//         parent::__construct($context);
//     }
 
//     public function execute()
//     {
//         $varOne = $this->getRequest()->getPostValue();
 
//         if (!$varOne) {
//             $this->messageManager->addErrorMessage(__('Invalid data. Please try again.'));
//             $this->_redirect('prod/customer/index');
//         }
 
//         $varModel = $this->customerFactory->create();
//         $varModel->setFirstName($varOne['first_name'])
//             ->setLastName($varOne['last_name'])
//             ->setEmail($varOne['email'])
//             ->setGender($varOne['gender'])
//             ->setBirthDate($varOne['birth_date'])
//             ->setProfileImage($varOne['profile_image'])
//             ->setAddress($varOne['address'])
//             ->setIsActive($varOne['is_active'])
//             ->setHobbies($varOne['hobbies'])
//             ->setNewsletterSubscription($varOne['newsletter_subscription']);
        
//         try {
//             $varModel->save();
//             $this->messageManager->addSuccessMessage(__('data has been saved.'));
//         } catch (\Exception $e) {
//             $this->messageManager->addErrorMessage(__('Something went wrong while saving the user data.'));
//             $this->_getSession()->setFormData($varOne);
//             $this->_redirect('prod/customer/index');
//         }
//         $this->_redirect('prod/customer/index');
//     }
// }