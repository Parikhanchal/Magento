<?php
namespace Kitchen\Product\Helper;

use \Magento\Framework\App\Helper\AbstractHelper;
 
class Data extends AbstractHelper
{
       public function getwebsite()
       {
        return "Hello Helper";
       }
}
