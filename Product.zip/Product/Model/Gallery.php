<?php

namespace Kitchen\Product\Model;

class Gallery extends \Magento\Framework\Model\AbstractModel
{
    public function _construct()
    {
        $this->_init(\Kitchen\Product\Model\ResourceModel\Gallery::class);
    }
}
