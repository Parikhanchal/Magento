// alert (1);

jQuery(document).ready( function() {
    jQuery("#btn2").click(function(){
        alert("Done");
    });
});

jQuery(document).ready( function() {
    jQuery(".btn").click(function(){
        alert("Done class");
    });
});