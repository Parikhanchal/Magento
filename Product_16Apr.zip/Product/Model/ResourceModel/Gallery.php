<?php

namespace Kitchen\Product\Model\ResourceModel;

class Gallery extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    protected function _construct()
    {
        $this->_init('product', 'entity_id');
        // $this->_init('kitchen_product', 'entity_id');
    }
}
