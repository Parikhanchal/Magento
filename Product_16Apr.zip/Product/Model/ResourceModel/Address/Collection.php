<?php

namespace Kitchen\Product\Model\ResourceModel\Address;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    protected $_idFieldName = 'entity_id';
    protected function _construct()
    {
        $this->_init(
            \Kitchen\Product\Model\Address::class,
            \Kitchen\Product\Model\ResourceModel\Address::class
        );
    }
}

