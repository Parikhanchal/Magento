<?php

namespace Kitchen\Product\Model\ResourceModel;

class Product extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    protected function _construct()
    {
        $this->_init('cp_product', 'entity_id');
    }
}
