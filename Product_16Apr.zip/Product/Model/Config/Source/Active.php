<?php

namespace Kitchen\Product\Model\Config\Source;

use Kitchen\Product\Model\GalleryFactory;

class Active implements \Magento\Framework\Option\ArrayInterface
{
    protected $galleryFactory;

    public function __construct(
        GalleryFactory $galleryFactory
    ) {
        $this->galleryFactory = $galleryFactory;
    }

    public function toOptionArray()
    {
        return [
            ['value' => '0', 'label' => 'Not Active'],
            ['value' => '1', 'label' => 'Active'],
        ];
    }
}
