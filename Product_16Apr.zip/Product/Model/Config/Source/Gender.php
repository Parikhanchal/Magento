<?php

namespace Kitchen\Product\Model\Config\Source;

use Kitchen\Product\Model\CustomerFactory;

class Gender implements \Magento\Framework\Option\ArrayInterface
{
    protected $CustomerFactory;

    public function __construct(
        CustomerFactory $CustomerFactory
    ) {
        $this->CustomerFactory = $CustomerFactory;
    }

    public function toOptionArray()
    {
        return [
            ['value' => 'Male', 'label' => 'Male'],
            ['value' => 'Female', 'label' => 'Female'],
        ];
    }
}