<?php

namespace Kitchen\Product\Model;

class Product extends \Magento\Framework\Model\AbstractModel
{
    public function _construct()
    {
        $this->_init(\Kitchen\Product\Model\ResourceModel\Product::class);
    }
}
