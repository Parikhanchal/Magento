<?php

namespace Kitchen\Product\Model;

class Address extends \Magento\Framework\Model\AbstractModel
{
    public function _construct()
    {
        $this->_init(\Kitchen\Product\Model\ResourceModel\Address::class);
    }
}
