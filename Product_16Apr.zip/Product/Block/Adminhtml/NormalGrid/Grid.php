<?php
namespace Kitchen\Product\Block\Adminhtml\Normalgrid;
 
use Kitchen\Product\Model\ProductFactory;
use Kitchen\Product\Model\Status;
use Kitchen\Product\Model\ResourceModel\Product\CollectionFactory as ProductCollectionFactory;
use Magento\Backend\Block\Template\Context;
use Magento\Backend\Helper\Data as BackendHelper;
use Magento\Framework\Registry;
use Magento\Backend\Block\Widget\Grid\Column;

class Grid extends \Magento\Backend\Block\Widget\Grid\Extended
{
    protected $_productFactory;
    protected $_productCollectionFactory;
    protected $_coreRegistry;
    protected $_status;
 
    public function __construct(
        ProductFactory $productFactory,
        ProductCollectionFactory $productCollectionFactory,
        Context $context,
        BackendHelper $backendHelper,
        Registry $coreRegistry,
        Status $status,
        array $data = []
    ) {
        $this->_coreRegistry = $coreRegistry;
        $this->_productFactory = $productFactory;
        $this->_productCollectionFactory = $productCollectionFactory;
        $this->_status = $status;
        parent::__construct($context, $backendHelper, $data);
    }
 
    protected function _construct()
    {
        parent::_construct();
        $this->setId('productGrid');
        $this->setDefaultSort('entity_id');
        $this->setDefaultDir('DESC');
        $this->setSaveParametersInSession(true);
        $this->setUseAjax(true);
    }
 
    protected function _prepareCollection()
    {
        $collection = $this->_productCollectionFactory->create();
        $this->setCollection($collection);
        return parent::_prepareCollection();
    }
 
    protected function _prepareColumns()
    {
        $this->addColumn(
            'entity_id',
            [
                'header' => __('Product ID'),
                'index' => 'entity_id',
                'header_css_class' => 'col-id',
                'column_css_class' => 'col-id',
                'sortable' => true,
            ]
        );
 
        $this->addColumn(
            'name',
            [
                'header' => __('Name'),
                'index' => 'name',
                'type' => 'text',
                'escape' => true,
                'sortable' => true,
            ]
        );
 
        $this->addColumn(
            'price',
            [
                'header' => __('Price'),
                'index' => 'price',
                'type' => 'text',
                'escape' => true,
                'sortable' => true,
            ]
        );
 
        $this->addColumn(
            'is_active',
            [
                'header' => __('Status'),
                'type' => 'options',
                'index' => 'is_active',
                'options' => $this -> _status -> getOptionArray(),
                'sortable' => true
            ]
        );
 
        $this->addColumn(
            'creation_time',
            [
                'header' => __('Created'),
                'type' => 'datetime',
                'index' => 'creation_time',
                'header_css_class' => 'col-date col-date-min-width',
                'column_css_class' => 'col-date',
                'sortable' => true,
            ]
        );
 
        $this->addColumn(
            'update_time',
            [
                'header' => __('Updated'),
                'type' => 'datetime',
                'index' => 'update_time',
                'header_css_class' => 'col-date col-date-min-width',
                'column_css_class' => 'col-date',
                'sortable' => true,
            ]
        );
    
        $this->addColumn(
            'action',
            [
                'header' => __('Action'),
                'type' => 'action',
                'getter' => 'getEntityId',
                'actions' => [
                    [
                        'caption' => __('Edit'),
                        'url' => ['base' => 'prod/normalGrid/edit'],
                        'field' => 'entity_id'
                    ],
                    [
                        'caption' => __('Delete'),
                        'url' => ['base' => 'prod/normalGrid/delete'],
                        'field' => 'entity_id',
                        'confirm' => [
                            'message' => __('Are you sure you want to delete this record?')
                        ]
                    ]
                ],
                'filter' => false,
                'sortable' => false,
                'index' => 'entity_id',
                'header_css_class' => 'col-action',
                'column_css_class' => 'col-action'
            ]
        );
 
        return parent::_prepareColumns();
    }
 
    protected function _prepareMassaction()
    {
        $this->setMassactionIdField('entity_id');
        $this->setMassactionIdFilter('entity_id');
        $this->setMassactionIdFieldOnlyIndexValue(true);
        $this->getMassactionBlock()->setFormFieldName('product');
 
        $this->getMassactionBlock()->addItem(
            'delete',
            [
                'label' => __('Delete'),
                'url' => $this->getUrl(
                    'prod/normalGrid/massdelete',
                    ['ret' => $this->_coreRegistry->registry('usePendingFilter') ? 'pending' : 'index']
                ),
                'confirm' => __('Are you sure?')
            ]
        );
    }
 
    protected function _prepareMassactionColumn()
    {
        parent::_prepareMassactionColumn();
        /** needs for correct work of mass action select functionality */
        $this->setMassactionIdField('entity_id');
 
        return $this;
    }
 
    /**
     * @return string
     */
    public function getGridUrl()
    {
        return $this->getUrl('prod/*/grid', ['_current' => true]);
    }
 
    /**
     * @return string
     */
    public function getRowUrl($row)
    {
        return $this->getUrl('prod/*/edit', ['entity_id' => $row->getId()]);
    }
 
}
