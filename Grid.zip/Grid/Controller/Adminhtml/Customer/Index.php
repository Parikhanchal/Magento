<?php

namespace Acp\Grid\Controller\Adminhtml\Customer;


class Index extends \Magento\Backend\App\Action
{
	const ADMIN_RESOURCE = 'Acp_Grid::new_grid';

	protected $resultPageFactory = false;

	public function __construct(
		\Magento\Backend\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $resultPageFactory
	)
	{
		parent::__construct($context);
		$this->resultPageFactory = $resultPageFactory;
	}

	public function execute()
	{
		 $resultPage = $this->resultPageFactory->create();
         $resultPage->setActiveMenu('Acp_Grid::new_grid');
         $resultPage->addBreadcrumb(__('review'), __('review'));
         $resultPage->addBreadcrumb(__('customer'), __('customer'));
         $resultPage->getConfig()->getTitle()->prepend((__('Grid Customer')));
		 

		 return $resultPage;
	}
}
