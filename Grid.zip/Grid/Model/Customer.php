<?php

namespace Acp\Grid\Model;

class Customer extends \Magento\Framework\Model\AbstractModel
{
    public function _construct()
    {
        $this->_init(\Acp\Grid\Model\ResourceModel\Customer::class);
    }
}
