<?php
namespace Acp\Email\Block;

use Magento\Framework\View\Element\Template;

class Index extends Template implements \Magento\Framework\View\Element\BlockInterface
{
    // Your block code goes here
}
