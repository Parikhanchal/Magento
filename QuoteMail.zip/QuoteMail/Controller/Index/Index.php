<?php
namespace Kitchen\QuoteMail\Controller\Index;

use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Action\Action;
use Magento\Framework\Mail\Template\TransportBuilder;
use Magento\Framework\Translate\Inline\StateInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Quote\Model\QuoteFactory;
use Magento\Customer\Api\CustomerRepositoryInterface;

class Index extends Action
{
    protected $transportBuilder;
    protected $inlineTranslation;
    protected $storeManager;
    protected $quoteFactory;
    protected $customerRepository;

    public function __construct(
        Context $context,
        TransportBuilder $transportBuilder,
        StateInterface $inlineTranslation,
        StoreManagerInterface $storeManager,
        QuoteFactory $quoteFactory,
        CustomerRepositoryInterface $customerRepository
    ) {
        parent::__construct($context);
        $this->transportBuilder = $transportBuilder;
        $this->inlineTranslation = $inlineTranslation;
        $this->storeManager = $storeManager;
        $this->quoteFactory = $quoteFactory;
        $this->customerRepository = $customerRepository;
    }

    public function execute()
    {
        $quoteId = $this->getRequest()->getParam('quote_id');
        $quote = $this->quoteFactory->create()->load($quoteId);

        if ($quote->getId()) {
            $customerId = $quote->getCustomerId();
            $customer = $this->customerRepository->getById($customerId);
            $customerEmail = $customer->getEmail();
            $quoteUrl = $this->storeManager->getStore()->getBaseUrl() . 'quotes/view/id/' . $quote->getId();

            try {
                $this->inlineTranslation->suspend();
                $transport = $this->transportBuilder
                    ->setTemplateIdentifier('quote_email_template') // Use the template ID from email_templates.xml
                    ->setTemplateOptions([
                        'area' => \Magento\Framework\App\Area::AREA_FRONTEND,
                        'store' => $this->storeManager->getStore()->getId()
                    ])
                    ->setTemplateVars(['quote_url' => $quoteUrl])
                    ->setFrom(['email' => 'your_store@example.com', 'name' => 'Your Store'])
                    ->addTo('enni@gmail.com')
                    ->getTransport();
                $transport->sendMessage();
                $this->inlineTranslation->resume();
                $this->messageManager->addSuccessMessage(__('Email sent successfully.'));
            } catch (\Exception $e) {
                $this->inlineTranslation->resume();
                $this->messageManager->addErrorMessage(__('Unable to send email.'));
            }
        } else {
            $this->messageManager->addErrorMessage(__('Quote not found.'));
        }

        // return $this->_redirect('/');
    }
}
