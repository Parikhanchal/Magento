<?php
namespace Kitchen\QuoteMail\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Event\Observer;
use Magento\Framework\Mail\Template\TransportBuilder;
use Magento\Framework\Translate\Inline\StateInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Customer\Api\CustomerRepositoryInterface;

class SendQuoteEmail implements ObserverInterface
{
    protected $transportBuilder;
    protected $inlineTranslation;
    protected $storeManager;
    protected $customerRepository;

    public function __construct(
        TransportBuilder $transportBuilder,
        StateInterface $inlineTranslation,
        StoreManagerInterface $storeManager,
        CustomerRepositoryInterface $customerRepository
    ) {
        $this->transportBuilder = $transportBuilder;
        $this->inlineTranslation = $inlineTranslation;
        $this->storeManager = $storeManager;
        $this->customerRepository = $customerRepository;
    }

    public function execute(Observer $observer)
    {
        // Get the newly created quote
        $quote = $observer->getEvent()->getQuote();

        // Replace with your logic to check if this is a new quote creation
        if ($quote->getId() && $quote->getOrigData('entity_id') === null) {
            // Get customer email
            $customerId = $quote->getCustomerId();
            $customer = $this->customerRepository->getById($customerId);
            $customerEmail = $customer->getEmail();

            // Generate quote URL (replace with your logic)
            $quoteUrl = $this->storeManager->getStore()->getBaseUrl() . 'quotes/view/id/' . $quote->getId();

            // Send email to customer
            $this->inlineTranslation->suspend();
            $transport = $this->transportBuilder
                ->setTemplateIdentifier('quote_email_template') // Use the template ID from email_templates.xml
                ->setTemplateOptions(['area' => \Magento\Framework\App\Area::AREA_FRONTEND, 'store' => $this->storeManager->getStore()->getId()])
                ->setTemplateVars(['quote_url' => $quoteUrl])
                ->setFrom(['email' => 'enni@gmail.com', 'name' => 'Your Store'])
                ->addTo($customerEmail)
                ->getTransport();
            $transport->sendMessage();
            $this->inlineTranslation->resume();
        }
    }
}
