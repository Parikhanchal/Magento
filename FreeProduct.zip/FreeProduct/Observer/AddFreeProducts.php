<?php

namespace K365\FreeProduct\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Catalog\Model\ProductFactory;
use Magento\Framework\Data\Form\FormKey;
use Magento\Checkout\Model\Cart;
use Magento\Framework\Event\Observer;

class AddFreeProducts implements ObserverInterface
{
    protected $_productFactory;
    protected $_cart;
    protected $formKey;
    protected $scopeConfig;

    public function __construct(
        ProductFactory $productFactory,
        FormKey $formKey,
        Cart $cart,
        ScopeConfigInterface $scopeConfig
    ) {
        $this->_productFactory = $productFactory;
        $this->formKey = $formKey;
        $this->_cart = $cart;
        $this->scopeConfig = $scopeConfig;
        // stockRegistry use for check stock status & qty
        // scopeConfig use for featch value (magento admin)
    }

    public function execute(Observer $observer)
    {
        // echo 1111111;die();
        $skuConfig = $this->scopeConfig->getValue('freeproduct_section/general/dynamic_options', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        // print_r($skuConfig);die();
        $scopConfigArray = json_decode($skuConfig, true);
        // print_r($scopConfigArray);die();

        if (empty($scopConfigArray)) {
            return;
        }

        $items = $this->_cart->getQuote()->getAllVisibleItems();

        foreach ($scopConfigArray as $config) {
            $productSku = $config['sku'];
            $freeProductSkus = explode(',', $config['free_product']);
            $isTriggerItem = false;
            $isFreeItem = false;
            $triggerItemQty = 0;

            foreach ($items as $item) {
                if ($item->getSku() == $productSku) {
                    $isTriggerItem = true;
                    $triggerItemQty = $item->getQty();
                }
                // print_r ($item->getSku());die();    

                if (in_array($item->getSku(), $freeProductSkus)) {
                    $isFreeItem = true;
                }
                // echo 2;
                //  print_r($freeProductSkus);
                // die;
            }
            
            // echo $isTriggerItem ;die;
            if ($isTriggerItem && !$isFreeItem) {
                // echo 111;die;
                foreach ($freeProductSkus as $freeProductSku) {
                    $_product = $this->_productFactory->create()->loadByAttribute('sku', $freeProductSku);
                    if ($_product) {
                        $params = [
                            'form_key' => $this->formKey->getFormKey(),
                            'product' => $_product->getId(),
                            'qty' => $triggerItemQty
                        ];
                        if ($isFreeItem) {
                            foreach ($items as $item) {
                                if ($item->getSku() == $freeProductSku) {
                                    $item->setQty($triggerItemQty);
                                }
                            }
                        } else {
                            $this->_cart->addProduct($_product, $params);
                        }
                    }
                }
                $this->_cart->save();
            }
        }
    }
}
